<html>
<head>
<title>OMP Analysis prototype</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/OMPsearch.js"></script>
</head>
<body>
<form id="search">
  <input id="keyword" type="text" value="">
  <input id="SearchContain" type="button" value="Search for contain that word">
  <input id="OrContain" type="button" value="Or contain that word">
  <input id="SearchNotContain" type="button" value="Search for not contain that word">
</form>

<div>Respons:<num id="num_respons"></num></div>
History:(click it to return status)<div class="history">You haven't search any word yet</div><br>
Search result:<num id="Searchresult"></num><br>

<?php
require_once('config.php');
require_once('lib/database.php');
require_once('lib/shared_funcs.php');

require_once('lib/forms.php');
require_once('lib/questionTypes.php');

$thisSession = isset($_REQUEST['sessionID'])? session::retrieve_session($_REQUEST['sessionID']):false;
$uinfo = checkLoggedInUser();
if(!checkPermission($uinfo, $thisSession))
{
	echo '<script language="javascript">;';
	echo 'alert("Sorry, Permission Error");';
	echo 'window.location = "index.php";';
	echo '</script>';
}
else
{
	$responses = response::retrieve_response_matching('question_id', $_REQUEST['qiID']);
	echo "<table id='respon' border='1'>". "\n"."<thead>". "\n"."<tr><th>User</th><th>Name</th><th>Response</th><th>respon time</th>". "\n"."</thead>". "\n"."<tbody>". "\n";
	foreach($responses as $r){
		$member = sessionMember::retrieve_sessionMember($r->user_id);
		echo "<tr>". "\n"."<td>{$member->userID}</td>". "\n"."<td>{$member->name}</td>". "\n"."<td>{$r->value}</td>". "\n"."<td>".date("Y-m-d H:i:s",$r->time)."</td></tr>". "\n";
	}
	echo "</table>". "\n";
}
?>
</body>
</html>